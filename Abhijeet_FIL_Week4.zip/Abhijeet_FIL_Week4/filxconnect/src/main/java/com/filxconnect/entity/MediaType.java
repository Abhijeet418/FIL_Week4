package com.filxconnect.entity;

public enum MediaType {
    IMAGE,  // Represents image media
    VIDEO   // Represents video media
}
