package com.filxconnect.entity;

public enum ReportStatus {
    PENDING,
    APPROVED,
    REJECTED
}
