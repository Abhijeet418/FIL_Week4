package com.filxconnect.service;

import org.springframework.stereotype.Service;

import com.filxconnect.entity.Follower;
import com.filxconnect.repository.FollowerRepository;

import java.util.List;
import java.util.UUID;

@Service
public class FollowerService {

    private final FollowerRepository followerRepository;

    // Constructor for dependency injection
    public FollowerService(FollowerRepository followerRepository) {
        this.followerRepository = followerRepository;
    }

    // Method to follow a user
    public Follower followUser(UUID followerId, UUID followingId) {
        Follower newFollower = new Follower();
        newFollower.setFollowerId(followerId);
        newFollower.setFollowingId(followingId);
        return followerRepository.save(newFollower);
    }

    // Method to unfollow a user
    public void unfollowUser(UUID followerId, UUID followingId) {
        followerRepository.deleteByFollowerIdAndFollowingId(followerId, followingId);
        System.out.println("User unfollowed");
    }

    // Method to get all followers of a user
    public List<Follower> getFollowersByUser(UUID userId) {
        return followerRepository.findByFollowingId(userId);
    }

    // Method to get all users a user is following
    public List<Follower> getFollowingByUser(UUID userId) {
        return followerRepository.findByFollowerId(userId);
    }
}
