package com.pictogram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PictogramApplicationTests {

	@Test
	void contextLoads() {
	}

}
