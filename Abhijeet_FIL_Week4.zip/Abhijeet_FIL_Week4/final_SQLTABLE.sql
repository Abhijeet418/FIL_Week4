drop database filxconnect;
create database filxconnect;
use filxconnect;
create table admins(
	aid BINARY(16) DEFAULT (UUID_TO_BIN(UUID())) PRIMARY KEY,
    aname VARCHAR(50) NOT NULL,
    aemail VARCHAR(100)  NOT NULL UNIQUE,
    apass VARCHAR(16) NOT NULL,
    aprofilepic TEXT,
    acreatedate TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    aupdatedate TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
CREATE TABLE users (
    id BINARY(16) DEFAULT (UUID_TO_BIN(UUID())) PRIMARY KEY,  -- UUID as Primary Key (Stored in Binary Format for Efficiency)
    username VARCHAR(50) NOT NULL UNIQUE,                     -- Unique Username
    email VARCHAR(100) NOT NULL UNIQUE,                       -- Unique Email
    password VARCHAR(255) NOT NULL,                           -- Hashed Password
    profile_picture TEXT DEFAULT NULL,                        -- Profile Picture (URL or Base64)
    bio TEXT DEFAULT NULL,                                    -- User Bio
    status INT NOT NULL DEFAULT 0,                     -- User Status (1 = Active, 0 = Inactive)
    reports INT NOT NULL DEFAULT 0,							  -- Number of times User gets Reported
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,           -- Auto-set Creation Time
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP  -- Auto-set Last Updated Time
);
CREATE TABLE post (
    id BINARY(16) NOT NULL PRIMARY KEY,
    caption VARCHAR(255) NULL,
    content VARCHAR(255) NULL,
    title VARCHAR(255) NULL,
    user_id BINARY(16) NOT NULL,
    status CHAR(1) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) -- Assuming 'users' is the related table
);
CREATE TABLE media (
    id BINARY(16) NOT NULL DEFAULT (UUID_TO_BIN(UUID())), -- Correct UUID storage
    post_id BINARY(16) NOT NULL, -- Foreign key linking to posts.id
    media_url TEXT NOT NULL,  -- Store image/video URL
    media_type ENUM('IMAGE', 'VIDEO') NOT NULL,  -- Type of media
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    FOREIGN KEY (post_id) REFERENCES post(id) ON DELETE CASCADE
);
CREATE TABLE likes (
    id BINARY(16) NOT NULL DEFAULT (UUID_TO_BIN(UUID())),  -- Unique ID for the like
    post_id BINARY(16) NOT NULL,  -- Foreign key referencing post.id
    user_id BINARY(16) NOT NULL,  -- Foreign key referencing users.id
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- Timestamp when the like was created
    PRIMARY KEY (id),
    FOREIGN KEY (post_id) REFERENCES post(id) ON DELETE CASCADE,  -- ✅ Correct reference to post.id
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE   -- ✅ Correct reference to users.id
);
CREATE TABLE notifications (
    id BINARY(16) NOT NULL DEFAULT (UUID_TO_BIN(UUID())), -- Unique identifier
    user_id BINARY(16) NOT NULL,
    post_id BINARY(16),
    -- User who receives the notification
    message TEXT NOT NULL, -- Notification message
    is_read BOOLEAN NOT NULL DEFAULT FALSE, -- Track if the notification has been read
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Timestamp when the notification was created
    PRIMARY KEY (id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (post_id) REFERENCES post(id)
);
CREATE TABLE messages (
    id BINARY(16) DEFAULT (UUID_TO_BIN(UUID())) PRIMARY KEY,
    sender_id BINARY(16) NOT NULL,
    receiver_id BINARY(16) NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE followers (
    id BINARY(16) NOT NULL PRIMARY KEY,
    follower_id BINARY(16) NOT NULL,
    following_id BINARY(16) NOT NULL,
    FOREIGN KEY (follower_id) REFERENCES users(id),
    FOREIGN KEY (following_id) REFERENCES users(id)
);
CREATE TABLE comments (
    id BINARY(16) NOT NULL PRIMARY KEY,
    content VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    post_id BINARY(16) NOT NULL,
    user_id BINARY(16) NOT NULL,
    FOREIGN KEY (post_id) REFERENCES post(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE TABLE reports (
    report_id BINARY(16) NOT NULL PRIMARY KEY,
    block_request_flag BIT(1) NOT NULL,
    reason VARCHAR(255) NULL,
    report_status ENUM('APPROVED', 'PENDING', 'REJECTED') NULL,
    reported_post_id BINARY(16) NULL,
    reported_user_id BINARY(16) NULL,
    reporter_user_id BINARY(16) NULL,
    timestamp DATETIME(6) NULL,
    FOREIGN KEY (reported_post_id) REFERENCES post(id),
    FOREIGN KEY (reported_user_id) REFERENCES users(id),
    FOREIGN KEY (reporter_user_id) REFERENCES users(id)
);
INSERT INTO admins (aid, aname, aemail, apass, aprofilepic) 
VALUES (1, 'Admin User', 'admin@example.com', 'securepass123', NULL);
INSERT INTO users (id, username, email, password, profile_picture, bio, status, reports, created_at, updated_at) VALUES
(1, 'john_doe', 'john.doe@example.com', 'Pass@123', 'john.jpg', 'Tech enthusiast and blogger.', 1, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(2, 'emily_smith', 'emily.smith@example.com', 'Pass@123', 'emily.jpg', 'Aspiring writer and traveler.', 3, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(3, 'michael_jones', 'michael.jones@example.com', 'Pass@123', 'michael.jpg', 'Software engineer and AI researcher.', 0, 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(4, 'sarah_johnson', 'sarah.johnson@example.com', 'Pass@123', 'sarah.jpg', 'Fitness coach and nutritionist.', 1, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(5, 'david_brown', 'david.brown@example.com', 'Pass@123', 'david.jpg', 'Photographer capturing life’s moments.', 3, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(6, 'jessica_miller', 'jessica.miller@example.com', 'Pass@123', 'jessica.jpg', 'Marketing specialist and entrepreneur.', 0, 3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(7, 'william_wilson', 'william.wilson@example.com', 'Pass@123', 'william.jpg', 'Gamer, streamer, and content creator.', 1, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(8, 'olivia_moore', 'olivia.moore@example.com', 'Pass@123', 'olivia.jpg', 'Fashion designer and artist.', 3, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(9, 'james_taylor', 'james.taylor@example.com', 'Pass@123', 'james.jpg', 'Crypto investor and fintech enthusiast.', 0, 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(10, 'sophia_anderson', 'sophia.anderson@example.com', 'Pass@123', 'sophia.jpg', 'Yoga instructor and mindfulness coach.', 1, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(11, 'benjamin_white', 'benjamin.white@example.com', 'Pass@123', 'benjamin.jpg', 'Automobile engineer and car enthusiast.', 3, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(12, 'ava_harris', 'ava.harris@example.com', 'Pass@123', 'ava.jpg', 'Food blogger and recipe creator.', 0, 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(13, 'ethan_martin', 'ethan.martin@example.com', 'Pass@123', 'ethan.jpg', 'Full-stack developer and mentor.', 1, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(14, 'mia_thompson', 'mia.thompson@example.com', 'Pass@123', 'mia.jpg', 'Travel vlogger exploring the world.', 3, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(15, 'alexander_garcia', 'alexander.garcia@example.com', 'Pass@123', 'alexander.jpg', 'Finance analyst and stock trader.', 0, 3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(16, 'charlotte_martinez', 'charlotte.martinez@example.com', 'Pass@123', 'charlotte.jpg', 'Startup founder and product manager.', 1, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(17, 'henry_robinson', 'henry.robinson@example.com', 'Pass@123', 'henry.jpg', 'Music producer and sound engineer.', 3, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(18, 'amelia_clark', 'amelia.clark@example.com', 'Pass@123', 'amelia.jpg', 'Mental health advocate and speaker.', 0, 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(19, 'lucas_rodriguez', 'lucas.rodriguez@example.com', 'Pass@123', 'lucas.jpg', 'Chef with a passion for fusion cuisine.', 1, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(20, 'isabella_hernandez', 'isabella.hernandez@example.com', 'Pass@123', 'isabella.jpg', 'Graphic designer and branding expert.', 3, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
INSERT INTO post (id, caption, content, title, user_id, status) VALUES
(1, 'Beautiful sunset', 'Captured this amazing sunset at the beach!', 'Sunset Bliss', 3, '1'),
(2, 'Workout motivation', 'Consistency is key to success!', 'Fitness Journey', 5, '1'),
(3, 'My new pet', 'Meet my adorable kitten, Luna!', 'Say Hi to Luna', 7, '3'),
(4, 'Weekend getaway', 'Exploring the mountains this weekend.', 'Nature Retreat', 10, '1'),
(5, 'Coding grind', 'Late-night coding session on my new project.', 'Hustle Mode', 2, '0'),
(6, 'Book recommendations', 'Here are my top 5 books for self-growth.', 'Must-Read Books', 4, '1'),
(7, 'Delicious brunch', 'Enjoying some pancakes and coffee this morning.', 'Brunch Time', 9, '3'),
(8, 'Travel bucket list', 'Planning my next trip to Greece!', 'Wanderlust', 6, '1'),
(9, 'Gaming setup', 'Finally upgraded my gaming rig!', 'PC Master Race', 11, '0'),
(10, 'Photography tips', 'How to take stunning landscape shots.', 'Camera Hacks', 8, '1'),
(11, 'New car reveal', 'Just got my dream car! 🚗', 'Speed and Style', 13, '3'),
(12, 'Best coding resources', 'Sharing the best online courses for developers.', 'Learn to Code', 14, '1'),
(13, 'Concert night', 'Saw my favorite band live!', 'Rock and Roll', 15, '0'),
(14, 'Healthy eating', 'Meal prepping for the week ahead.', 'Nutrition Tips', 12, '1'),
(15, 'DIY home decor', 'Made this beautiful wall art myself!', 'Creative Touch', 16, '1'),
(16, 'Startup journey', 'My first steps as an entrepreneur.', 'Building Dreams', 17, '3'),
(17, 'Sneaker collection', 'My top 10 sneakers of all time.', 'Sneakerhead Diaries', 18, '1'),
(18, 'New music drop', 'Releasing my new single this Friday!', 'Music Vibes', 19, '0'),
(19, 'Hiking adventure', 'Conquered a new trail today!', 'Nature Explorer', 20, '1'),
(20, 'Minimalist lifestyle', 'How I simplified my life.', 'Less is More', 3, '3'),
(21, 'Anime recommendations', 'Top 5 must-watch anime!', 'Otaku Picks', 5, '1'),
(22, 'Street photography', 'Capturing the raw beauty of urban life.', 'City Aesthetics', 7, '0'),
(23, 'Coding challenge', 'Can you solve this algorithm puzzle?', 'Brain Teaser', 10, '1'),
(24, 'Productivity hacks', 'Best tips for staying focused and efficient.', 'Work Smarter', 2, '1'),
(25, 'First marathon', 'Completed my first 10K run!', 'Runner’s High', 4, '3'),
(26, 'Home workout', 'No gym? No problem!', 'Stay Fit Anywhere', 9, '1'),
(27, 'Self-care routine', 'My daily habits for mental wellness.', 'Mindful Living', 6, '1'),
(28, 'Tech innovations', 'The future of AI and automation.', 'Tech Trends', 11, '0'),
(29, 'Gourmet cooking', 'Tried making a Michelin-star dish at home!', 'Masterchef Mode', 8, '1'),
(30, 'New painting', 'Finished my latest artwork!', 'Creative Flow', 13, '3'),
(31, 'Pet adoption story', 'Rescued this lovely doggo today.', 'Furry Friend', 14, '1'),
(32, 'Online learning', 'Best free courses to upskill.', 'Level Up', 15, '1'),
(33, 'Road trip memories', 'Driving across the country was amazing!', 'Adventure Awaits', 12, '0'),
(34, 'Startup funding', 'Secured my first investment!', 'Entrepreneur Life', 16, '1'),
(35, 'Coffee lovers', 'Best coffee shops in town.', 'Caffeine Fix', 17, '3'),
(36, 'Sci-fi movies', 'My all-time favorite sci-fi classics.', 'Movie Buff', 18, '1'),
(37, 'Sports highlight', 'Epic moment from last night’s game!', 'Game On', 19, '1'),
(38, 'Interior design', 'Modern home decor ideas.', 'Aesthetic Spaces', 20, '3'),
(39, 'Mental health awareness', 'Let’s talk about mental health.', 'Break the Stigma', 3, '1'),
(40, 'Fitness transformation', 'Before and after – my fitness journey.', 'Stronger Every Day', 5, '1'),
(41, 'Space exploration', 'The latest Mars rover updates.', 'Beyond Earth', 7, '0'),
(42, 'Cooking hacks', 'Quick and easy meals in under 15 minutes.', 'Kitchen Secrets', 10, '1'),
(43, 'Travel photography', 'Best destinations for photographers.', 'Picture Perfect', 2, '1'),
(44, 'Gadget review', 'Testing the new iPhone.', 'Tech Geek', 4, '3'),
(45, 'Music playlist', 'My go-to workout tracks.', 'Beats & Reps', 9, '1'),
(46, 'Sustainable living', 'Simple ways to reduce your carbon footprint.', 'Go Green', 6, '1'),
(47, 'Historical facts', 'Mind-blowing history facts you didn’t know.', 'Did You Know?', 11, '0'),
(48, 'Coding bootcamp', 'My experience with a coding bootcamp.', 'Dev Journey', 8, '1'),
(49, 'Luxury watches', 'Top 5 watches to invest in.', 'Timeless Pieces', 13, '3'),
(50, 'Horror movies', 'Best horror films for a spooky night.', 'Fear Factor', 14, '1');

INSERT INTO likes (id, user_id, post_id, created_at) VALUES
(1, 3, 1, CURRENT_TIMESTAMP),
(2, 5, 2, CURRENT_TIMESTAMP),
(3, 7, 3, CURRENT_TIMESTAMP),
(4, 10, 4, CURRENT_TIMESTAMP),
(5, 2, 5, CURRENT_TIMESTAMP),
(6, 8, 6, CURRENT_TIMESTAMP),
(7, 12, 7, CURRENT_TIMESTAMP),
(8, 14, 8, CURRENT_TIMESTAMP),
(9, 1, 9, CURRENT_TIMESTAMP),
(10, 6, 10, CURRENT_TIMESTAMP),
(11, 15, 11, CURRENT_TIMESTAMP),
(12, 9, 12, CURRENT_TIMESTAMP),
(13, 4, 13, CURRENT_TIMESTAMP),
(14, 18, 14, CURRENT_TIMESTAMP),
(15, 11, 15, CURRENT_TIMESTAMP);
INSERT INTO comments (id, user_id, post_id, content, created_at) VALUES
(1, 4, 1, 'Great insights on tech trends! Looking forward to your blog.', CURRENT_TIMESTAMP),
(2, 6, 2, 'Bali is on my bucket list! Any recommendations?', CURRENT_TIMESTAMP),
(3, 8, 3, 'AGI is fascinating but also a bit scary!', CURRENT_TIMESTAMP),
(4, 10, 4, 'Hydration is key! I always carry a water bottle.', CURRENT_TIMESTAMP),
(5, 12, 5, 'That sunset looks unreal! Where was this taken?', CURRENT_TIMESTAMP),
(6, 3, 6, 'I need those marketing tips! Link?', CURRENT_TIMESTAMP),
(7, 15, 7, 'Excited for your gaming stream! 🎮', CURRENT_TIMESTAMP),
(8, 9, 8, 'Your fashion collection is stunning! Where can I buy?', CURRENT_TIMESTAMP),
(9, 11, 9, 'Crypto is unpredictable, but I’m still holding!', CURRENT_TIMESTAMP),
(10, 2, 10, 'Morning yoga is a game changer! 🧘‍♂️', CURRENT_TIMESTAMP);
INSERT INTO media (id, post_id, media_url, media_type) VALUES
(1, 1, 'https://cdn.example.com/sunset.jpg', 'IMAGE'),
(2, 2, 'https://cdn.example.com/workout.mp4', 'VIDEO'),
(3, 3, 'https://cdn.example.com/kitten.jpg', 'IMAGE'),
(4, 4, 'https://cdn.example.com/mountains.jpg', 'IMAGE'),
(5, 5, 'https://cdn.example.com/coding.jpg', 'IMAGE'),
(6, 6, 'https://cdn.example.com/bookshelf.jpg', 'IMAGE'),
(7, 7, 'https://cdn.example.com/brunch.jpg', 'IMAGE'),
(8, 8, 'https://cdn.example.com/greece.jpg', 'IMAGE'),
(9, 9, 'https://cdn.example.com/gaming-setup.jpg', 'IMAGE'),
(10, 10, 'https://cdn.example.com/landscape-tips.mp4', 'VIDEO'),
(11, 12, 'https://cdn.example.com/coding-resources.jpg', 'IMAGE'),
(12, 15, 'https://cdn.example.com/diy-art.jpg', 'IMAGE'),
(13, 18, 'https://cdn.example.com/music-cover.jpg', 'IMAGE'),
(14, 25, 'https://cdn.example.com/marathon.jpg', 'IMAGE'),
(15, 30, 'https://cdn.example.com/painting.jpg', 'IMAGE');

INSERT INTO followers (id, follower_id, following_id) VALUES
(UUID_TO_BIN(UUID()), 1, 2),
(UUID_TO_BIN(UUID()), 3, 5),
(UUID_TO_BIN(UUID()), 4, 6),
(UUID_TO_BIN(UUID()), 7, 8),
(UUID_TO_BIN(UUID()), 9, 10),
(UUID_TO_BIN(UUID()), 11, 2),
(UUID_TO_BIN(UUID()), 13, 5),
(UUID_TO_BIN(UUID()), 14, 9),
(UUID_TO_BIN(UUID()), 16, 18),
(UUID_TO_BIN(UUID()), 19, 20),
(UUID_TO_BIN(UUID()), 2, 3),
(UUID_TO_BIN(UUID()), 5, 7),
(UUID_TO_BIN(UUID()), 6, 9),
(UUID_TO_BIN(UUID()), 8, 12),
(UUID_TO_BIN(UUID()), 10, 13);

INSERT INTO reports (
    report_id, block_request_flag, reason, report_status, reported_post_id, reported_user_id, reporter_user_id, timestamp
) VALUES
(1, 1, 'Spam content', 'PENDING', 5, NULL, 12, NOW(6)),
(2, 0, 'Hate speech', 'APPROVED', 8, NULL, 15, NOW(6)),
(3, 1, 'Inappropriate content', 'PENDING', 12, NULL, 6, NOW(6)),
(4, 0, 'Misleading information', 'REJECTED', 22, NULL, 18, NOW(6)),
(5, 1, 'Harassment', 'APPROVED', NULL, 3, 9, NOW(6)),
(6, 0, 'Plagiarism', 'PENDING', 30, NULL, 14, NOW(6)),
(7, 1, 'Fake news', 'REJECTED', 33, NULL, 20, NOW(6)),
(8, 0, 'Copyright infringement', 'APPROVED', 41, NULL, 7, NOW(6)),
(9, 1, 'Harmful content', 'PENDING', NULL, 8, 13, NOW(6)),
(10, 0, 'False accusations', 'REJECTED', 45, NULL, 11, NOW(6)),
(11, 1, 'Impersonation', 'APPROVED', NULL, 17, 19, NOW(6)),
(12, 0, 'Violence', 'PENDING', 10, NULL, 5, NOW(6)),
(13, 1, 'Self-harm content', 'APPROVED', NULL, 4, 16, NOW(6)),
(14, 0, 'Scam', 'REJECTED', 26, NULL, 1, NOW(6)),
(15, 1, 'Abusive language', 'PENDING', NULL, 2, 10, NOW(6)),
(16, 0, 'Sexual harassment', 'APPROVED', 39, NULL, 17, NOW(6)),
(17, 1, 'Racism', 'PENDING', 48, NULL, 3, NOW(6)),
(18, 0, 'Threats', 'REJECTED', 15, NULL, 8, NOW(6)),
(19, 1, 'False identity', 'APPROVED', NULL, 11, 7, NOW(6)),
(20, 0, 'Violent content', 'PENDING', 50, NULL, 6, NOW(6));


